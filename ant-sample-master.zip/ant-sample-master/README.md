# Sample Ant-based Java project

This is an example of Java project with Ant build file.

Run the following command in the project directory:

* `ant -p` to list all available targets,
* `ant build` to build project (jar file),
* `ant run` to run sample application,
* `ant doc` to generate documentation,
* `ant clean` to clean up project folder.

