package piona;

/**
 * Main class.
 */
public class Main {
    
    /**
     * Application entry point.
     * 
     * @param args Application arguments.
     */
    public static void main(String[] args) {
        HelloWorld hw = new HelloWorld();
        System.out.println(hw);
    }
}

